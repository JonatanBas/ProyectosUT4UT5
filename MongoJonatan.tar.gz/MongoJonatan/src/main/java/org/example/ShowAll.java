package org.example;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import javax.swing.text.Document;
import java.util.ArrayList;
import java.util.List;

public class ShowAll
{
    public static void main(String[] args)
    {
        MongoClient mc = new MongoClient();
        MongoDatabase mdb = mc.getDatabase("Tienda");
        MongoCollection mco = mdb.getCollection("Smartphones");

        FindIterable fit = mco.find();
        //Obtenemos un mongoCursor.
        MongoCursor<Smarthpone> cursor = fit.iterator();
        //Por cada elemento del cursor mostramos el artista.
        while (cursor.hasNext())
            System.out.println(cursor.next());

    /*
        -Método alternativo más laborioso
        //Array a recorrer
        List<Smarthpone> Moviles = new ArrayList<>();
        //Documento de filtrado(?)
        Document doc1 = new Document("Nombre", "Oneplus Nord2");
        FindIterable It = mco.find(doc1);
        MongoCursor mCur = It.iterator();
        while (mCur.hasNext())
        {
            doc1 = (Document)mCur.next();
            Smarthpone s1 = new Smarthpone();
            s1.setName(doc1.getString("Modelo: "));
            s1.setScreen(doc1.getDouble("Pantalla: "));
            s1.setWeight(doc1.getDouble("Peso: "));
            s1.setPrice(doc1.getDouble("Precio:"));
            Moviles.add(s1);
        }

        //DISPLAY
        for(int i=0 ; i<Moviles.size() ; i++)
            System.out.println(s1);
        mc.close();

     */
    }
}
