package org.example;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class Delete
{
    public static void main(String[] args)
    {
        //CONEXIÓN
        MongoClient mc = new MongoClient();
        MongoDatabase mdb = mc.getDatabase("Tienda");
        MongoCollection mco = mdb.getCollection("Smartphones");

        //BORRADO SINGULAR
        mco.deleteMany(new Document("name","Galaxy_S23"));
        //BORRADO PLURAL
        //mco.deleteMany(new Document("price","$gt", 500));

        mc.close();
    }
}
