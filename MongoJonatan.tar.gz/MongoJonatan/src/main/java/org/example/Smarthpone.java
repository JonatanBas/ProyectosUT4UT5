package org.example;

public class Smarthpone
{
    //ATRIBUTOS
    private String name;
    private double screen;
    private double weight;
    private double price;
    //CONSTRUCTOR
    public Smarthpone(String name, double screen, double weight, double price) {
        this.name = name;
        this.screen = screen;
        this.weight = weight;
        this.price = price;
    }

    //SETTERS
    public void setName(String name) {
        this.name = name;
    }

    public void setScreen(double screen) {
        this.screen = screen;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    //GETTERS
    public String getName() {
        return name;
    }

    public double getScreen() {
        return screen;
    }

    public double getWeight() {
        return weight;
    }

    public double getPrice() {
        return price;
    }

    //MÉTODOS
    @Override
    public String toString() {
        return "Smarthpone{" +
                "name='" + name + '\'' +
                ", screen=" + screen +
                ", weight=" + weight +
                ", price=" + price +
                '}';
    }
}
