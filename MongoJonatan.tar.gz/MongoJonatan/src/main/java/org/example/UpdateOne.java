package org.example;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import javax.swing.text.Document;

public class UpdateOne
{
    public static void main(String[] args)
    {
        MongoClient mc = new MongoClient();
        MongoDatabase mdb = mc.getDatabase("Tienda");
        MongoCollection mco = mdb.getCollection("Smartphones");

        Document base = new Document("name","HTC One");
        Document updt = new Document("$set", new Document("peso",200));
        mco.updateOne(base, updt);
        mc.close();
    }
}
