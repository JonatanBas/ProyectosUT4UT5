package org.example;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class UpdateMany
{
    public static void main(String[] args)
    {
        //Conexión
        MongoClient mc = new MongoClient();
        MongoDatabase mdb = mc.getDatabase("Tienda");
        MongoCollection mco = mdb.getCollection("Smartphones");

        //Update
        Document base = new Document();
        //Document update = new Document("name","Iphone");
        Document update = new Document("$inc", new Document("price",100));
        mco.updateMany(base,update);
        mc.close();
    }
}
