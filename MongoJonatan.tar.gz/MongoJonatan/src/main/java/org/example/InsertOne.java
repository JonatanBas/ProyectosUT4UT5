package org.example;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import javax.swing.text.Document;

public class InsertOne
{
    public static void main(String[] args)
    {
        //Creamos cliente para la conexión
        MongoClient mc = new MongoClient();
        //Creamos BBDD para alojar Colección
        MongoDatabase mdb = mc.getDatabase("Tienda");
        //Colección mco alojará el document con el objeto s1
        MongoCollection mco = mdb.getCollection("Smartphones");

        //Creamos el objeto
        Smarthpone s1 = new Smarthpone("Galaxy_S23", 6.7,200,1400);
        //Declaramos documento para alojar objetos, y con append y getters, añadimos a doc
        Document doc = new Document("_id",s1.getName())
                .append("Pantalla: ", s1.getScreen())
                .append("Peso: ", s1.getWeight())
                .append("Precio: ", s1.getPrice());
        //Insertamos en la colección
        mco.insertOne(doc);
        mc.close();
    }
}
