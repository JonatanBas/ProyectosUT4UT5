package org.example;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import javax.swing.text.Document;
import java.util.ArrayList;
import java.util.List;

public class InsertMany
{
    public static void main(String[] args)
    {
        MongoClient mc = new MongoClient();
        MongoDatabase mdb = mc.getDatabase("Tienda");
        MongoCollection mco = mdb.getCollection("Smartphones");

        /*
            -Los objetos se almacenarán en el array.
            -El array se alojará de golpe en el documento.
            -Es similar a un doc embebido.
        */

        List<Document> DocSmart = new ArrayList<>();
        Smarthpone s1 = new Smarthpone("Iphone",6,180,1200);
        Smarthpone s2 = new Smarthpone("Xiaomi", 6.4, 220,600);
        Smarthpone s3 = new Smarthpone("Oneplus", 6.1,180,600);
        Smarthpone s4 = new Smarthpone("Realme",6.6,240,400);

        //Igual a InsertMany, salvo en add()
        Document doc = new Document("_id",s1.getName())
                .append("Pantalla: ", s1.getScreen())
                .append("Peso: ", s1.getWeight())
                .append("Precio: ", s1.getPrice())
                DocSmart.add(doc);

        Document doc = new Document("_id",s2.getName())
                .append("Pantalla: ", s2.getScreen())
                .append("Peso: ", s2.getWeight())
                .append("Precio: ", s2.getPrice())
        DocSmart.add(doc);

        Document doc = new Document("_id",s2.getName())
                .append("Pantalla: ", s2.getScreen())
                .append("Peso: ", s2.getWeight())
                .append("Precio: ", s2.getPrice())
        DocSmart.add(doc);

        Document doc = new Document("_id",s1.getName())
                .append("Pantalla: ", s1.getScreen())
                .append("Peso: ", s1.getWeight())
                .append("Precio: ", s1.getPrice())
        DocSmart.add(doc);

        //Ahora, el embebido
        mco.insertMany(DocSmart);
        mc.close();



    }
}
