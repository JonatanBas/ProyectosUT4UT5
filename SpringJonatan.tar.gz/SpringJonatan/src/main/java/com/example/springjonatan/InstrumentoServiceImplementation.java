package com.example.springjonatan;

import com.example.springjonatan.model.Instrumento;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

@Service
public class InstrumentoServiceImplementation implements InstrumentoService
{
    @Autowired
    private InstrumentoRepository ir;

    public ArrayList<Instrumento> findAll(){
        return (ArrayList<Instrumento>)ir.findAll();
    }
    public Optional<Instrumento> findById(Long id){
        return ir.findById(id);
    }
    public void saveInstrumento(Instrumento instrumento){
        ir.save(instrumento);
    }
    public Instrumento updateInstrumento(Long id, Instrumento instrumento){
        if(ir.findById(id)!=null)
        {
            ir.save(instrumento);
            return instrumento;
        }
        return null;
    }
    public void deleteInstrumentoById(Long id){
        ir.deleteById(id);
    }
}
