package com.example.springjonatan.controller;

import com.example.springjonatan.InstrumentoServiceImplementation;
import com.example.springjonatan.model.Instrumento;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class WebController {
    @Autowired
    private InstrumentoServiceImplementation isi;
    @GetMapping("/Saludos, Ricardo!")
    public String Saludar(){
        return "Hola Ricardo!";
    }
    @PostMapping("/Alta")
    public void Guardar(Instrumento instrumento){
        isi.saveInstrumento(instrumento);
    }
    @GetMapping(" /instrumentos")
    public List<Instrumento> ListarTodos(){
        return isi.findAll();
    }
    @PutMapping("/instrumentos(id)")
    public Instrumento Actualizar(@PathVariable Long id, Instrumento instrumento){
        return isi.updateInstrumento(id, instrumento);
    }
    @DeleteMapping("/instrumentos/{id}")
    public String Borrar(@PathVariable Long id){
        isi.deleteInstrumentoById(id);
        return "Borrado completado";
    }
}
