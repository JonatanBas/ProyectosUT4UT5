package com.example.springjonatan;

import com.example.springjonatan.model.Instrumento;

import java.util.ArrayList;
import java.util.Optional;

public interface InstrumentoService
{
    //Método para cargar en una lista
    ArrayList<Instrumento> findAll();
    //Método que retorna según id
    Optional<Instrumento>findById(Long id);
    //Método para guardar instrumento como parámetro
    void saveInstrumento(Instrumento instrumento);




     /* Actualiza un Instrumento con 2 parámetros:
        1. el id del producto a cambiar
        2. el instrumento con los valores del resto de campos a modificar
        Hacemos que retorne el instrumento modificado
     */
    Instrumento updateInstrumento(Long id, Instrumento instrumento);


    //Borrado de Instrumentos
    void deleteInstrumentoById(Long instrumentoId);


}
