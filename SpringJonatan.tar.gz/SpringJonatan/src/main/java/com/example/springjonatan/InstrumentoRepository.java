package com.example.springjonatan;

import com.example.springjonatan.model.Instrumento;
import org.springframework.data.repository.CrudRepository;

public interface InstrumentoRepository extends CrudRepository<Instrumento,Long> {
}
